module exercise1

go 1.26.1

require (
	github.com/golang-jwt/jwt/v5 v5.3.1 // indirect
	github.com/google/uuid v1.6.0 // indirect
	github.com/gorilla/mux v1.8.1 // indirect
	golang.org/x/crypto v0.50.0 // indirect
)
