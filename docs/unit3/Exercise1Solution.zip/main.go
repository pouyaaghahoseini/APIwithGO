package main

import (
	"context"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"math/rand"
	"net/http"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/golang-jwt/jwt/v5"
	"github.com/google/uuid"
	"github.com/gorilla/mux"
	"golang.org/x/crypto/bcrypt"
)

var jwtSecret = []byte("change-this-secret-key-in-production")

// Models
type User struct {
	ID           int       `json:"id"`
	Username     string    `json:"username"`
	Email        string    `json:"email"`
	PasswordHash string    `json:"-"`
	FullName     string    `json:"full_name"`
	Bio          string    `json:"bio"`
	Role         string    `json:"role"`
	CreatedAt    time.Time `json:"created_at"`
	UpdatedAt    time.Time `json:"updated_at"`
	Verified     bool      `json:"verified"`
}

type Claims struct {
	UserID   int    `json:"user_id"`
	Username string `json:"username"`
	Role     string `json:"role"`
	jwt.RegisteredClaims
}

type RefreshToken struct {
	Token     string
	UserID    int
	ExpiresAt time.Time
}

type VerificationCode struct {
	UserID    int
	Code      string
	ExpiresAt time.Time
}
type PasswordResetToken struct {
	UserID    int
	Token     string
	ExpiresAt time.Time
}

var (
	resetTokens = make(map[string]PasswordResetToken)
	resetMu     sync.RWMutex
)

var (
	verifications = make(map[int]VerificationCode)
	verifyMu      sync.RWMutex
)

// Storage
var (
	users      = make(map[int]User)
	usernames  = make(map[string]int)
	emails     = make(map[string]int)
	nextUserID = 1
	usersMu    sync.RWMutex
)

var (
	refreshTokens = make(map[string]RefreshToken)
	refreshMu     sync.RWMutex
)

type contextKey string

const UserContextKey contextKey = "user"

// =============================================================================
// CORS MIDDLEWARE
// =============================================================================

func corsMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		// Allow requests from any origin (for development)
		w.Header().Set("Access-Control-Allow-Origin", "*")
		w.Header().Set("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
		w.Header().Set("Access-Control-Allow-Headers", "Content-Type, Authorization")

		// Handle preflight OPTIONS request
		if r.Method == "OPTIONS" {
			w.WriteHeader(http.StatusOK)
			return
		}

		next.ServeHTTP(w, r)
	})
}

func generateRefreshToken(userID int) (string, error) {
	// Generate random token
	token := uuid.New().String()

	refreshMu.Lock()
	refreshTokens[token] = RefreshToken{
		Token:     token,
		UserID:    userID,
		ExpiresAt: time.Now().Add(7 * 24 * time.Hour),
	}
	refreshMu.Unlock()

	return token, nil
}

func refreshHandler(w http.ResponseWriter, r *http.Request) {
	var req struct {
		RefreshToken string `json:"refresh_token"`
	}

	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		respondError(w, http.StatusBadRequest, "Invalid JSON")
		return
	}

	// Validate refresh token
	refreshMu.RLock()
	rt, exists := refreshTokens[req.RefreshToken]
	refreshMu.RUnlock()

	if !exists {
		respondError(w, http.StatusUnauthorized, "Invalid refresh token")
		return
	}

	if time.Now().After(rt.ExpiresAt) {
		respondError(w, http.StatusUnauthorized, "Refresh token expired")
		return
	}

	// Get user
	usersMu.RLock()
	user := users[rt.UserID]
	usersMu.RUnlock()

	// Generate new access token
	accessToken, err := generateToken(user.ID, user.Username, user.Role)
	if err != nil {
		respondError(w, http.StatusInternalServerError, "Failed to generate token")
		return
	}

	respondJSON(w, http.StatusOK, map[string]string{
		"access_token": accessToken,
	})
}

// =============================================================================
// AUTHENTICATION HANDLERS
// =============================================================================

func registerHandler(w http.ResponseWriter, r *http.Request) {
	var req struct {
		Username string `json:"username"`
		Email    string `json:"email"`
		Password string `json:"password"`
		FullName string `json:"full_name"`
	}

	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		respondError(w, http.StatusBadRequest, "Invalid JSON")
		return
	}
	defer r.Body.Close()

	// Validate username
	if err := validateUsername(req.Username); err != nil {
		respondError(w, http.StatusBadRequest, err.Error())
		return
	}

	// Validate email
	if err := validateEmail(req.Email); err != nil {
		respondError(w, http.StatusBadRequest, err.Error())
		return
	}

	// Validate password
	if err := validatePassword(req.Password); err != nil {
		respondError(w, http.StatusBadRequest, err.Error())
		return
	}

	// Validate full name
	if req.FullName != "" && (len(req.FullName) < 2 || len(req.FullName) > 50) {
		respondError(w, http.StatusBadRequest, "Full name must be between 2 and 50 characters")
		return
	}

	// Check uniqueness
	usersMu.RLock()
	_, usernameExists := usernames[req.Username]
	_, emailExists := emails[req.Email]
	usersMu.RUnlock()

	if usernameExists {
		respondError(w, http.StatusConflict, "Username already exists")
		return
	}

	if emailExists {
		respondError(w, http.StatusConflict, "Email already exists")
		return
	}

	// Hash password
	hashedPassword, err := bcrypt.GenerateFromPassword([]byte(req.Password), bcrypt.DefaultCost)
	if err != nil {
		respondError(w, http.StatusInternalServerError, "Failed to process password")
		return
	}

	// Create user
	now := time.Now()
	usersMu.Lock()
	user := User{
		ID:           nextUserID,
		Username:     req.Username,
		Email:        req.Email,
		PasswordHash: string(hashedPassword),
		FullName:     req.FullName,
		Bio:          "",
		Role:         "user",
		CreatedAt:    now,
		UpdatedAt:    now,
	}
	users[nextUserID] = user
	usernames[req.Username] = nextUserID
	emails[req.Email] = nextUserID
	nextUserID++
	usersMu.Unlock()

	// Generate token
	token, err := generateToken(user.ID, user.Username, user.Role)
	if err != nil {
		respondError(w, http.StatusInternalServerError, "Failed to generate token")
		return
	}

	// Generate verification code
	code := generateRandomCode(6)

	verifyMu.Lock()
	verifications[user.ID] = VerificationCode{
		UserID:    user.ID,
		Code:      code,
		ExpiresAt: time.Now().Add(24 * time.Hour),
	}
	verifyMu.Unlock()

	// In production: send email with code
	fmt.Printf("Verification code for %s: %s\n", user.Email, code)

	// Return response
	respondJSON(w, http.StatusCreated, map[string]interface{}{
		"user":  user,
		"token": token,
	})
}

func verifyHandler(w http.ResponseWriter, r *http.Request) {
	var req struct {
		Email string `json:"email"`
		Code  string `json:"code"`
	}

	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		respondError(w, http.StatusBadRequest, "Invalid JSON")
		return
	}

	// Find user by email
	usersMu.RLock()
	userID, exists := emails[req.Email]
	if !exists {
		usersMu.RUnlock()
		respondError(w, http.StatusNotFound, "User not found")
		return
	}
	usersMu.RUnlock()

	// Check verification code
	verifyMu.RLock()
	vc, exists := verifications[userID]
	verifyMu.RUnlock()

	if !exists || vc.Code != req.Code {
		respondError(w, http.StatusBadRequest, "Invalid verification code")
		return
	}

	if time.Now().After(vc.ExpiresAt) {
		respondError(w, http.StatusBadRequest, "Verification code expired")
		return
	}

	// Mark user as verified
	usersMu.Lock()
	user := users[userID]
	user.Verified = true
	users[userID] = user
	usersMu.Unlock()

	// Delete verification code
	verifyMu.Lock()
	delete(verifications, userID)
	verifyMu.Unlock()

	respondJSON(w, http.StatusOK, map[string]string{
		"message": "Account verified successfully",
	})
}

func loginHandler(w http.ResponseWriter, r *http.Request) {
	var req struct {
		Login    string `json:"login"` // Can be username or email
		Password string `json:"password"`
	}

	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		respondError(w, http.StatusBadRequest, "Invalid JSON")
		return
	}
	defer r.Body.Close()

	// Try to find user by username or email
	usersMu.RLock()
	var user User
	var exists bool

	// Try username first
	if userID, ok := usernames[req.Login]; ok {
		user = users[userID]
		exists = true
	} else if userID, ok := emails[req.Login]; ok {
		// Try email
		user = users[userID]
		exists = true
	}
	usersMu.RUnlock()

	if !exists {
		respondError(w, http.StatusUnauthorized, "Invalid credentials")
		return
	}

	// Verify password
	err := bcrypt.CompareHashAndPassword([]byte(user.PasswordHash), []byte(req.Password))
	if err != nil {
		respondError(w, http.StatusUnauthorized, "Invalid credentials")
		return
	}

	// Generate access token (15 min)
	accessToken, _ := generateToken(user.ID, user.Username, user.Role)

	// Generate refresh token (7 days)
	refreshToken, _ := generateRefreshToken(user.ID)

	respondJSON(w, http.StatusOK, map[string]interface{}{
		"access_token":  accessToken,
		"refresh_token": refreshToken,
		"user":          user,
	})
}

// =============================================================================
// PROFILE HANDLERS
// =============================================================================

func getProfileHandler(w http.ResponseWriter, r *http.Request) {
	claims, ok := getUserFromContext(r)
	if !ok {
		respondError(w, http.StatusUnauthorized, "Unauthorized")
		return
	}

	usersMu.RLock()
	user, exists := users[claims.UserID]
	usersMu.RUnlock()

	if !exists {
		respondError(w, http.StatusNotFound, "User not found")
		return
	}

	respondJSON(w, http.StatusOK, user)
}

func updateProfileHandler(w http.ResponseWriter, r *http.Request) {
	claims, ok := getUserFromContext(r)
	if !ok {
		respondError(w, http.StatusUnauthorized, "Unauthorized")
		return
	}

	var req struct {
		FullName string `json:"full_name"`
		Bio      string `json:"bio"`
	}

	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		respondError(w, http.StatusBadRequest, "Invalid JSON")
		return
	}
	defer r.Body.Close()

	// Validate
	if req.FullName != "" && (len(req.FullName) < 2 || len(req.FullName) > 50) {
		respondError(w, http.StatusBadRequest, "Full name must be between 2 and 50 characters")
		return
	}

	if len(req.Bio) > 500 {
		respondError(w, http.StatusBadRequest, "Bio must be 500 characters or less")
		return
	}

	// Update user
	usersMu.Lock()
	user, exists := users[claims.UserID]
	if !exists {
		usersMu.Unlock()
		respondError(w, http.StatusNotFound, "User not found")
		return
	}

	user.FullName = req.FullName
	user.Bio = req.Bio
	user.UpdatedAt = time.Now()
	users[claims.UserID] = user
	usersMu.Unlock()

	respondJSON(w, http.StatusOK, user)
}

func changePasswordHandler(w http.ResponseWriter, r *http.Request) {
	claims, ok := getUserFromContext(r)
	if !ok {
		respondError(w, http.StatusUnauthorized, "Unauthorized")
		return
	}

	var req struct {
		CurrentPassword string `json:"current_password"`
		NewPassword     string `json:"new_password"`
	}

	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		respondError(w, http.StatusBadRequest, "Invalid JSON")
		return
	}
	defer r.Body.Close()

	// Get user
	usersMu.RLock()
	user, exists := users[claims.UserID]
	usersMu.RUnlock()

	if !exists {
		respondError(w, http.StatusNotFound, "User not found")
		return
	}

	// Verify current password
	err := bcrypt.CompareHashAndPassword([]byte(user.PasswordHash), []byte(req.CurrentPassword))
	if err != nil {
		respondError(w, http.StatusUnauthorized, "Current password is incorrect")
		return
	}

	// Validate new password
	if err := validatePassword(req.NewPassword); err != nil {
		respondError(w, http.StatusBadRequest, err.Error())
		return
	}

	// Check new password is different
	if req.CurrentPassword == req.NewPassword {
		respondError(w, http.StatusBadRequest, "New password must be different from current password")
		return
	}

	// Hash new password
	hashedPassword, err := bcrypt.GenerateFromPassword([]byte(req.NewPassword), bcrypt.DefaultCost)
	if err != nil {
		respondError(w, http.StatusInternalServerError, "Failed to process password")
		return
	}

	// Update password
	usersMu.Lock()
	user.PasswordHash = string(hashedPassword)
	user.UpdatedAt = time.Now()
	users[claims.UserID] = user
	usersMu.Unlock()

	respondJSON(w, http.StatusOK, map[string]string{
		"message": "Password updated successfully",
	})
}

func deleteAccountHandler(w http.ResponseWriter, r *http.Request) {
	claims, ok := getUserFromContext(r)
	if !ok {
		respondError(w, http.StatusUnauthorized, "Unauthorized")
		return
	}

	usersMu.Lock()
	user, exists := users[claims.UserID]
	if !exists {
		usersMu.Unlock()
		respondError(w, http.StatusNotFound, "User not found")
		return
	}

	// Delete user
	delete(users, claims.UserID)
	delete(usernames, user.Username)
	delete(emails, user.Email)
	usersMu.Unlock()

	w.WriteHeader(http.StatusNoContent)
}

// POST /forgot-password - Request password reset
func forgotPasswordHandler(w http.ResponseWriter, r *http.Request) {
	var req struct {
		Email string `json:"email"`
	}

	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		respondError(w, http.StatusBadRequest, "Invalid JSON")
		return
	}
	defer r.Body.Close()

	// Validate email format
	if err := validateEmail(req.Email); err != nil {
		respondError(w, http.StatusBadRequest, err.Error())
		return
	}

	// Find user by email
	usersMu.RLock()
	userID, exists := emails[req.Email]
	usersMu.RUnlock()

	// Always return success to prevent email enumeration
	// In production, only send email if user exists
	if exists {
		// Generate secure reset token
		token := generateSecureToken()

		resetMu.Lock()
		resetTokens[token] = PasswordResetToken{
			UserID:    userID,
			Token:     token,
			ExpiresAt: time.Now().Add(1 * time.Hour), // Token valid for 1 hour
		}
		resetMu.Unlock()

		// In production: send email with reset link
		// Example: https://yourapp.com/reset-password?token=xxx
		fmt.Printf("Password reset token for %s: %s\n", req.Email, token)
	}

	respondJSON(w, http.StatusOK, map[string]string{
		"message": "If an account with that email exists, a password reset link has been sent",
	})
}

// POST /reset-password - Use token to set new password
func resetPasswordHandler(w http.ResponseWriter, r *http.Request) {
	var req struct {
		Token       string `json:"token"`
		NewPassword string `json:"new_password"`
	}

	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		respondError(w, http.StatusBadRequest, "Invalid JSON")
		return
	}
	defer r.Body.Close()

	// Validate token
	if req.Token == "" {
		respondError(w, http.StatusBadRequest, "Reset token is required")
		return
	}

	// Validate new password
	if err := validatePassword(req.NewPassword); err != nil {
		respondError(w, http.StatusBadRequest, err.Error())
		return
	}

	// Find and validate reset token
	resetMu.RLock()
	resetToken, exists := resetTokens[req.Token]
	resetMu.RUnlock()

	if !exists {
		respondError(w, http.StatusBadRequest, "Invalid or expired reset token")
		return
	}

	if time.Now().After(resetToken.ExpiresAt) {
		// Clean up expired token
		resetMu.Lock()
		delete(resetTokens, req.Token)
		resetMu.Unlock()
		respondError(w, http.StatusBadRequest, "Reset token has expired")
		return
	}

	// Hash new password
	hashedPassword, err := bcrypt.GenerateFromPassword([]byte(req.NewPassword), bcrypt.DefaultCost)
	if err != nil {
		respondError(w, http.StatusInternalServerError, "Failed to process password")
		return
	}

	// Update user password
	usersMu.Lock()
	user, userExists := users[resetToken.UserID]
	if !userExists {
		usersMu.Unlock()
		respondError(w, http.StatusNotFound, "User not found")
		return
	}

	user.PasswordHash = string(hashedPassword)
	user.UpdatedAt = time.Now()
	users[resetToken.UserID] = user
	usersMu.Unlock()

	// Delete used reset token (one-time use)
	resetMu.Lock()
	delete(resetTokens, req.Token)
	resetMu.Unlock()

	respondJSON(w, http.StatusOK, map[string]string{
		"message": "Password has been reset successfully",
	})
}

// =============================================================================
// VALIDATION FUNCTIONS
// =============================================================================

func validateUsername(username string) error {
	username = strings.TrimSpace(username)

	if len(username) < 3 || len(username) > 20 {
		return errors.New("Username must be between 3 and 20 characters")
	}

	// Alphanumeric and underscores only
	validUsername := regexp.MustCompile(`^[a-zA-Z0-9_]+$`)
	if !validUsername.MatchString(username) {
		return errors.New("Username can only contain letters, numbers, and underscores")
	}

	return nil
}

func validateEmail(email string) error {
	email = strings.TrimSpace(email)

	if email == "" {
		return errors.New("Email is required")
	}

	// Simple email regex
	emailRegex := regexp.MustCompile(`^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$`)
	if !emailRegex.MatchString(email) {
		return errors.New("Invalid email format")
	}

	return nil
}

func validatePassword(password string) error {
	if len(password) < 8 {
		return errors.New("Password must be at least 8 characters")
	}

	hasUpper := regexp.MustCompile(`[A-Z]`).MatchString(password)
	hasLower := regexp.MustCompile(`[a-z]`).MatchString(password)
	hasNumber := regexp.MustCompile(`[0-9]`).MatchString(password)

	if !hasUpper || !hasLower || !hasNumber {
		return errors.New("Password must contain uppercase, lowercase, and number")
	}

	return nil
}

func adminMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		claims, ok := getUserFromContext(r)
		if !ok {
			respondError(w, http.StatusUnauthorized, "Unauthorized")
			return
		}

		if claims.Role != "admin" {
			respondError(w, http.StatusForbidden, "Admin access required")
			return
		}

		next.ServeHTTP(w, r)
	})
}

// GET /api/admin/users?search=john - Search users (admin only)
func adminSearchUsersHandler(w http.ResponseWriter, r *http.Request) {
	// Get search query parameter
	searchQuery := strings.ToLower(strings.TrimSpace(r.URL.Query().Get("search")))

	// Optional pagination parameters
	page := 1
	limit := 20

	if p := r.URL.Query().Get("page"); p != "" {
		if parsed, err := strconv.Atoi(p); err == nil && parsed > 0 {
			page = parsed
		}
	}

	if l := r.URL.Query().Get("limit"); l != "" {
		if parsed, err := strconv.Atoi(l); err == nil && parsed > 0 && parsed <= 100 {
			limit = parsed
		}
	}

	// Search users
	usersMu.RLock()
	var results []User

	for _, user := range users {
		// Search in username, email, and full name
		if searchQuery == "" ||
			strings.Contains(strings.ToLower(user.Username), searchQuery) ||
			strings.Contains(strings.ToLower(user.Email), searchQuery) ||
			strings.Contains(strings.ToLower(user.FullName), searchQuery) {
			results = append(results, user)
		}
	}
	usersMu.RUnlock()

	// Sort by ID for consistent ordering
	sort.Slice(results, func(i, j int) bool {
		return results[i].ID < results[j].ID
	})

	// Apply pagination
	total := len(results)
	start := (page - 1) * limit
	end := start + limit

	if start > total {
		start = total
	}
	if end > total {
		end = total
	}

	paginatedResults := results[start:end]

	// Return paginated response
	respondJSON(w, http.StatusOK, map[string]interface{}{
		"users": paginatedResults,
		"pagination": map[string]interface{}{
			"page":        page,
			"limit":       limit,
			"total":       total,
			"total_pages": (total + limit - 1) / limit,
		},
	})
}

// =============================================================================
// JWT FUNCTIONS
// =============================================================================

func generateToken(userID int, username, role string) (string, error) {
	claims := Claims{
		UserID:   userID,
		Username: username,
		Role:     role,
		RegisteredClaims: jwt.RegisteredClaims{
			ExpiresAt: jwt.NewNumericDate(time.Now().Add(24 * time.Hour)),
			IssuedAt:  jwt.NewNumericDate(time.Now()),
		},
	}

	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	return token.SignedString(jwtSecret)
}

// Generate cryptographically secure token
func generateSecureToken() string {
	b := make([]byte, 32)
	if _, err := rand.Read(b); err != nil {
		// Fallback to UUID if crypto/rand fails
		return uuid.New().String()
	}
	return base64.URLEncoding.EncodeToString(b)
}

func validateToken(tokenString string) (*Claims, error) {
	token, err := jwt.ParseWithClaims(tokenString, &Claims{}, func(token *jwt.Token) (interface{}, error) {
		// Verify signing method
		if _, ok := token.Method.(*jwt.SigningMethodHMAC); !ok {
			return nil, fmt.Errorf("unexpected signing method: %v", token.Header["alg"])
		}
		return jwtSecret, nil
	})

	if err != nil {
		return nil, err
	}

	if claims, ok := token.Claims.(*Claims); ok && token.Valid {
		return claims, nil
	}

	return nil, errors.New("invalid token")
}

// =============================================================================
// MIDDLEWARE
// =============================================================================

func authMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		authHeader := r.Header.Get("Authorization")
		if authHeader == "" {
			respondError(w, http.StatusUnauthorized, "Authorization header required")
			return
		}

		parts := strings.Split(authHeader, " ")
		if len(parts) != 2 || parts[0] != "Bearer" {
			respondError(w, http.StatusUnauthorized, "Invalid authorization header format")
			return
		}

		claims, err := validateToken(parts[1])
		if err != nil {
			respondError(w, http.StatusUnauthorized, "Invalid or expired token")
			return
		}

		ctx := context.WithValue(r.Context(), UserContextKey, claims)
		next.ServeHTTP(w, r.WithContext(ctx))
	})
}

// =============================================================================
// HELPERS
// =============================================================================

func getUserFromContext(r *http.Request) (*Claims, bool) {
	user, ok := r.Context().Value(UserContextKey).(*Claims)
	return user, ok
}

func respondJSON(w http.ResponseWriter, status int, data interface{}) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	json.NewEncoder(w).Encode(data)
}

func respondError(w http.ResponseWriter, status int, message string) {
	respondJSON(w, status, map[string]string{"error": message})
}

func generateRandomCode(length int) string {
	const charset = "0123456789"
	code := make([]byte, length)
	for i := range code {
		code[i] = charset[rand.Intn(len(charset))]
	}
	return string(code)
}

// =============================================================================
// MAIN
// =============================================================================

func main() {
	r := mux.NewRouter()

	// Apply CORS middleware to all routes
	r.Use(corsMiddleware)

	// Public routes
	r.HandleFunc("/register", registerHandler).Methods("POST", "OPTIONS")
	r.HandleFunc("/login", loginHandler).Methods("POST", "OPTIONS")
	r.HandleFunc("/verify", verifyHandler).Methods("POST", "OPTIONS")
	r.HandleFunc("/refresh", refreshHandler).Methods("POST", "OPTIONS")
	r.HandleFunc("/forgot-password", forgotPasswordHandler).Methods("POST", "OPTIONS")
	r.HandleFunc("/reset-password", resetPasswordHandler).Methods("POST", "OPTIONS")

	// Protected routes
	api := r.PathPrefix("/api").Subrouter()
	api.Use(authMiddleware)

	api.HandleFunc("/profile", getProfileHandler).Methods("GET", "OPTIONS")
	api.HandleFunc("/profile", updateProfileHandler).Methods("PUT", "OPTIONS")
	api.HandleFunc("/password", changePasswordHandler).Methods("PUT", "OPTIONS")
	api.HandleFunc("/account", deleteAccountHandler).Methods("DELETE", "OPTIONS")

	// Admin routes
	admin := api.PathPrefix("/admin").Subrouter()
	admin.Use(adminMiddleware)
	admin.HandleFunc("/users", adminSearchUsersHandler).Methods("GET", "OPTIONS")

	fmt.Println("Server starting on :8080")
	http.ListenAndServe(":8080", r)
}
